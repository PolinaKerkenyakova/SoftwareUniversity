/* TODO: 
	create phonebook array
	add methods for adding in the phonebook and getting it
	export the methods
*/